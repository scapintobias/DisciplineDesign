export default function Footer() {
	return (
		<footer>
			<div className='relative overflow-hidden bg-black text-neutral-200'>
				<div className='relative px-6 py-24 mx-auto max-w-7xl'>
					<div className='grid gap-16 md:grid-cols-4'>
						<div className='space-y-6 md:col-span-2'>
							<div>
								<h2 className='text-3xl font-extrabold tracking-tight text-ruby-400'>
									Discipline<span className='text-white'>Design</span>
								</h2>
								<h3>Software a misura d'uomo</h3>
							</div>
							<h5 className='max-w-md leading-relaxed text-neutral-400'>
								Mettiamo ordine prima del codice: traduciamo bisogni in
								interfacce chiare e pronte per essere sviluppate senza intoppi.
							</h5>
						</div>

						<div className='space-y-6'>
							<h3 className='text-xs font-semibold tracking-wide uppercase text-neutral-100'>
								Parliamone
							</h3>
							<p className='text-sm leading-relaxed text-neutral-400'>
								Raccontaci la tua sfida: iniziamo con un confronto gratuito e
								senza impegno.
							</p>

							<button
								type='submit'
								className='group relative w-full overflow-hidden rounded-xl bg-ruby-500 px-4 py-2.5 text-sm font-semibold tracking-wide text-white shadow-lg shadow-ruby-500/30 transition hover:bg-ruby-400 focus:outline-none focus:ring-2 focus:ring-ruby-400/60'>
								<span className='relative z-10'>scrivici</span>
								<span className='absolute inset-0 transition-transform duration-300 translate-y-full bg-gradient-to-t from-black/40 to-transparent group-hover:translate-y-0'></span>
							</button>
						</div>
						{/* <div className='space-y-6 text-sm'>
							<h3 className='text-xs font-semibold tracking-wide uppercase text-neutral-100'>
								Contatto
							</h3>
							<ul className='space-y-3'>
								<li>
									<a
										href='mailto:info@discipline.design'
										className='transition hover:text-white text-neutral-400'>
										info@discipline.design
									</a>
								</li>
								<li className='text-neutral-400'>
									Via Esempio 12
									<br />
									20100 Milano (IT)
								</li>
								<li>
									<span className='text-neutral-400'>P.IVA 01234567890</span>
								</li>
							</ul>
						</div> */}
					</div>

					<div className='flex flex-col gap-6 pt-8 mt-20 border-t border-neutral-700/40 md:flex-row md:items-center md:justify-between'>
						<p className='text-xs text-neutral-500'>
							© {new Date().getFullYear()} DisciplineDesign. Tutti i diritti
							riservati.
						</p>
						{/* <ul className='flex flex-wrap text-xs gap-x-8 gap-y-3 text-neutral-500'>
							<li>
								<a href='#' className='transition hover:text-neutral-300'>
									Privacy
								</a>
							</li>
							<li>
								<a href='#' className='transition hover:text-neutral-300'>
									Termini
								</a>
							</li>
							<li>
								<a href='#' className='transition hover:text-neutral-300'>
									Cookie
								</a>
							</li>
							<li>
								<a href='#' className='transition hover:text-neutral-300'>
									Accessibility
								</a>
							</li>
						</ul> */}
					</div>
				</div>
			</div>
		</footer>
	);
}
